/* ======================================================
   e-Learn TSM MUPA
   ------------------------------------------------------
   File        : auth.js
   Version     : 2.0.0
   Description : Authentication & User Session
====================================================== */

const Auth = {
  /* ======================================================
     LOGIN
  ====================================================== */

  async login(username, password) {
    const user = await API.login(username, password);

    /* ------------------------------------------
       Validasi
    ------------------------------------------ */

    if (!user) {
      throw new Error("Username atau password salah.");
    }

    /* ------------------------------------------
       Simpan session user
    ------------------------------------------ */

    Storage.set("user", user);

    AppState.user = {
      ...AppState.user,

      ...user,

      login: true,
    };

    /* ------------------------------------------
       Tentukan mode berdasarkan role
    ------------------------------------------ */

    const role = String(user.role || "")
      .trim()
      .toLowerCase();

    if (["siswa", "ortu", "guru", "admin"].includes(role)) {
      AppState.setUserMode(role);
    }

    /* ------------------------------------------
       Terapkan layout
    ------------------------------------------ */

    if (typeof applyApplicationLayout === "function") {
      applyApplicationLayout();
    }

    return user;
  },

  /* ======================================================
     LOGOUT
  ====================================================== */

  logout() {
    /* ------------------------------------------
       Hapus session user
    ------------------------------------------ */

    Storage.remove("user");

    /* ------------------------------------------
       Reset user
    ------------------------------------------ */

    AppState.user = {
      login: false,

      username: "",

      nama: "",

      role: CONFIG.DEFAULT_ROLE,
    };

    /* ------------------------------------------
       Tentukan kembali mode
       
       Jika masih ada classAccess:
       → KELAS

       Jika tidak:
       → PUBLIC
    ------------------------------------------ */

    if (AppState.classAccess && AppState.classAccess.active) {
      AppState.setKelas(AppState.classAccess.kode);
    } else {
      AppState.setPublic();
    }

    /* ------------------------------------------
       Terapkan layout
    ------------------------------------------ */

    if (typeof applyApplicationLayout === "function") {
      applyApplicationLayout();
    }

    /* ------------------------------------------
       Kembali ke Dashboard
    ------------------------------------------ */

    window.location.hash = "#dashboard";
  },

  /* ======================================================
     CURRENT USER
  ====================================================== */

  user() {
    return Storage.get("user");
  },

  /* ======================================================
     CHECK LOGIN
  ====================================================== */

  check() {
    const user = Storage.get("user");

    if (!user) {
      AppState.user = {
        login: false,

        username: "",

        nama: "",

        role: CONFIG.DEFAULT_ROLE,
      };

      return false;
    }

    AppState.user = {
      ...AppState.user,

      ...user,

      login: true,
    };

    /* ------------------------------------------
       Restore role / LMS mode
    ------------------------------------------ */

    const role = String(user.role || "")
      .trim()
      .toLowerCase();

    if (["siswa", "ortu", "guru", "admin"].includes(role)) {
      AppState.setUserMode(role);
    }

    return true;
  },

  /* ======================================================
     ROLE
  ====================================================== */

  role() {
    return AppState.user.login ? AppState.user.role : null;
  },

  /* ======================================================
     ADMIN
  ====================================================== */

  isAdmin() {
    return this.role() === "admin";
  },

  /* ======================================================
     GURU
  ====================================================== */

  isGuru() {
    return this.role() === "guru";
  },

  /* ======================================================
     ORTU
  ====================================================== */

  isOrtu() {
    return this.role() === "ortu";
  },

  /* ======================================================
     SISWA
  ====================================================== */

  isSiswa() {
    return this.role() === "siswa";
  },

  /* ======================================================
     AUTHENTICATED
  ====================================================== */

  isAuthenticated() {
    return AppState.user.login === true;
  },
};

/* ======================================================
   READY
====================================================== */

console.log("Auth Ready");
